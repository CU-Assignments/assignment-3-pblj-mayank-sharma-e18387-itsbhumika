import java.util.HashMap;
import java.util.Scanner;

class CourseFullException extends Exception {
    public CourseFullException(String message) {
        super(message);
    }
}

class PrerequisiteNotMetException extends Exception {
    public PrerequisiteNotMetException(String message) {
        super(message);
    }
}

class UniversityEnrollmentSystem {
    private static final int MAX_CAPACITY = 2;
    private static HashMap<String, Integer> courseSeats = new HashMap<>();
    private static HashMap<String, String> prerequisites = new HashMap<>();

    static {
        courseSeats.put("Advanced Java", 2);
        prerequisites.put("Advanced Java", "Core Java");
    }

    public static void enrollStudent(String course, boolean prerequisiteCompleted)
            throws CourseFullException, PrerequisiteNotMetException {
        if (prerequisites.containsKey(course) && !prerequisiteCompleted) {
            throw new PrerequisiteNotMetException(
                    "Error: Complete " + prerequisites.get(course) + " before enrolling in " + course + ".");
        }

        if (courseSeats.get(course) <= 0) {
            throw new CourseFullException("Error: The course " + course + " is full.");
        }

        courseSeats.put(course, courseSeats.get(course) - 1);
        System.out.println("Enrollment successful for " + course);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enroll in Course: ");
        String course = scanner.nextLine();

        System.out.print("Prerequisite completed (true/false): ");
        boolean prerequisiteCompleted = scanner.nextBoolean();

        try {
            enrollStudent(course, prerequisiteCompleted);
        } catch (CourseFullException | PrerequisiteNotMetException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println("Error: Invalid input.");
        } finally {
            scanner.close();
        }
    }
}